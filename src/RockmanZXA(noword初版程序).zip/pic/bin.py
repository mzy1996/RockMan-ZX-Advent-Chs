from struct import unpack, pack
import os
import ndspy.lz10
from io import BytesIO


def align_up(size, align):
    return ((size + align - 1) & ~(align - 1))


class Bin(list):
    def __init__(self, io=None):
        if io:
            self.load(io)

    def load(self, io):
        num, = unpack('I', io.read(4))
        offsets = unpack(f'{num}I', io.read(4 * num))
        for i, offset in enumerate(offsets):
            io.seek(self.__get_offset(offset), os.SEEK_SET)
            if i + 1 == num:
                zbuf = io.read()
            else:
                zbuf = io.read(self.__get_offset(offsets[i + 1]) - self.__get_offset(offset))
            if self.__is_compress(offset):
                self.append(ndspy.lz10.decompress(zbuf))
            else:
                self.append(zbuf)

    def save(self, io):
        io.write(pack('I', len(self)))
        offset = 8 + 4 * len(self)
        _io = BytesIO()
        for f in self:
            io.write(pack('I', offset + _io.tell()))
            _io.write(f)
            _io.seek(align_up(_io.tell(), 4), os.SEEK_SET)
        io.write(pack('I', offset + _io.tell()))
        io.write(_io.getvalue())

    def __is_compress(self, offset):
        return offset >> 31 == 1

    def __get_offset(self, offset):
        return offset & 0x7fffffff

    def __str__(self):
        s = []
        offset = 8 + 4 * len(self)
        for i, b in enumerate(self):
            s.append(f'{i} {offset:08x} {len(b):08x}')
            offset += len(b)
            offset = align_up(offset, 4)
        return '\n'.join(s)

    def dump(self, index):
        open(f'{index}.bin', 'wb').write(self[index])

    def dump_all(self):
        for i in range(len(self)):
            self.dump(i)


if __name__ == '__main__':
    b = Bin(open('obj_fnt.bin', 'rb'))
    # b.save(open('test.bin', 'wb'))
    print(b)
    b.dump_all()
