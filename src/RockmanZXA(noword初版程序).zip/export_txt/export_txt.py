import sys
sys.path.append('../../libs')
from trans import Translation
from io import BytesIO
from pathlib import Path
from struct import unpack
import os
from bin import *


t = Translation('../import_txt/ZXAJP.xlsx').get_trans(index='Jpn')
trans = Translation()
tab = get_tab()
for path in Path('backup').glob('*.bin'):
    b = Bin(tab, open(path, 'rb'))
    for s in b:
        if s in t:
            cn = t[s]['Chs']
        else:
            cn = ''
        trans.append({'File': path.name, 'Jpn': s, 'Chs': cn})
trans.save('ZXAJP.xlsx', index='Jpn')
