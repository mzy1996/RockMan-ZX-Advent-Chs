from struct import unpack, pack
import os
from io import BytesIO
import re


def get_tab(name='ZXAJP.txt'):
    tab = {}
    for line in open(name, encoding='utf-8'):
        line = line.strip('\n')
        code, c = line.split('=', 1)
        tab[int(code, 16)] = c
    return tab


def encode_hex(code):
    s = ''
    while code > 0:
        s = '[%02x]' % (code & 0xff) + s
        code >>= 8
    return s


def read_str(io, tab):
    s = ''
    code = 0
    while True:
        # print('%x' % io.tell())
        b = ord(io.read(1))
        if b == 0xfe:
            break
        elif b == 0xff:
            s = None
            break
        elif b == 0xf0:
            b = ord(io.read(1))
            if b == 0xff:
                code = 0xf0ff00 | ord(io.read(1))
            else:
                code = 0xf000 | b
            # s += tab[code]
            if code in tab:
                s += tab[code]
            else:
                s += encode_hex(code)
        elif b > 0xf0:
            if b in (0xf1, 0xf2, 0xf3, 0xf4, 0xf6, 0xf7, 0xf8):
                s += '[%02x][%02x]' % (b, ord(io.read(1)))
            elif b == 0xfc:
                s += '\n'
            elif b in (0xfa, 0xfb, 0xfd):
                s += '[%02x]' % b
            elif b in (0xf9, ):
                s += '[%02x][%02x][%02x]' % (b, ord(io.read(1)), ord(io.read(1)))
            else:
                print(s)
                print('%x' % b)
                raise
        else:
            s += tab[b]
    return s


def write_str(io, s, tab):
    count = 0
    while count < len(s):
        c = s[count]
        if c == '[' and re.match(r'\[[\dabcdef]{2}\]', s[count:count + 4]):
            # print(s[count + 1:count + 3])
            # print(int(s[count + 1:count + 3], 16).to_bytes(1, 'big'))
            # raise
            io.write(int(s[count + 1:count + 3], 16).to_bytes(1, 'big'))
            count += 3
        elif c in ('\r', '\n'):
            io.write(b'\xfc')
        else:
            cc = c = tab[c]
            size = 0
            while cc > 0:
                size += 1
                cc >>= 8
            if size == 0:
                size = 1
            io.write(c.to_bytes(length=size, byteorder='big'))
        count += 1

    io.write(b'\xfe')


class Bin(list):
    def __init__(self, tab, io=None):
        self.tab = tab
        self.encode_tab = dict((v, k) for k, v in tab.items())
        if io:
            self.load(io)

    def load(self, io):
        total_size, offset_size = unpack('HH', io.read(4))
        offsets = unpack(f'{offset_size//2}H', io.read(offset_size))
        data_offset = io.tell()
        for i, offset in enumerate(offsets):
            if offset == 0 and i > 0:
                self.append(None)
            else:
                io.seek(data_offset + offset, os.SEEK_SET)
                self.append(read_str(io, self.tab))
                # print('%x' % (data_offset + offset), self[-1])

        # print('%x' % total_size, '%x' % io.tell())
        # assert total_size + 3 == io.tell()

    def save(self, io):
        io.write(pack('HH', 0, len(self) * 2))
        data_io = BytesIO()
        for s in self:
            if s is None:
                io.write(pack('H', 0))
            else:
                io.write(pack('H', data_io.tell()))
                write_str(data_io, s, self.encode_tab)
        io.write(data_io.getvalue())
        io.write(b'\xff')
        size = io.tell()
        io.seek(0, os.SEEK_SET)
        io.write(pack('H', size - 4))
