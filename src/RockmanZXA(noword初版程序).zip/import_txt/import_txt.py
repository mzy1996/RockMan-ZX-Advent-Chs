import sys
sys.path.append('../../libs')
sys.path.append('../export_txt')
from trans import Translation
from pathlib import Path
from bin import *
sys.stdout.reconfigure(encoding='utf-8')
import shutil


def _gen_tab(texts):
    count = 0
    tab = {}
    level = 1
    for t in texts:
        tab[t] = count
        count += 1
        if count == 0xf0:
            count = 0xf000
        elif count & 0xff == 0xff:
            count = 0
            for i in range(level):
                count |= 0xff << (8 * (i + 1))
            level += 1
            count |= 0xf0 << (8 * level)

    return tab


def gen_tab(texts):
    tab = {}
    count = 0
    for t in texts:
        tab[t] = count
        count += 1
        if count == 0xe0:
            count = 0xe000
        elif count & 0xff == 0xe0:
            count &= 0xff00
            count += 0x100
    return tab


if __name__ == '__main__':
    DEBUG = False
    # DEBUG = True

    for t in Translation('../import_txt/ZXAJP.xlsx').check_vars(r'\[[\dabcdef]{2}\]', 'Jpn', 'Chs'):
        print(t)
    trans = Translation('../import_txt/ZXAJP.xlsx').get_trans(index='Jpn')
    texts = {}
    for t in trans.values():
        for c in t['Jpn']:
            if c in texts:
                texts[c] += 1
            else:
                texts[c] = 1
        for c in t['Chs']:
            if c in texts:
                if ord(c) > 0x100 or c == ' ':
                    texts[c] += 10000
            else:
                texts[c] = 10000

    texts.pop('\n')
    _texts = ' 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    chars_list = list(filter(lambda x: x[0] not in _texts, texts.items()))
    chars_list.sort(key=lambda x: x[1], reverse=True)
    texts = _texts + "".join([x[0] for x in chars_list])

    open('../font/chars.txt', 'w', encoding='utf-8').write(texts)

    encode_tab = gen_tab(texts)
    if DEBUG:
        for i, (c, code) in enumerate(encode_tab.items()):
            print('%x' % i, c, '%x' % code)

    # for k, v in encode_tab.items():
    #     print(k, '%x' % v)
    # raise
    decode_tab = get_tab('../export_txt/ZXAJP.txt')

    for path in Path('../export_txt/backup').glob('*.bin'):
        old_size = path.stat().st_size
        b = Bin(decode_tab, open(path, 'rb'))
        b.encode_tab = encode_tab
        for i, s in enumerate(b):
            if s in trans and len(trans[s]['Chs']) > 0:
                b[i] = trans[s]['Chs']
        b.save(open(path.name, 'wb'))
        if old_size < Path(path.name).stat().st_size:
            print(path, old_size, Path(path.name).stat().st_size)
            # shutil.copy(path, path.name)
