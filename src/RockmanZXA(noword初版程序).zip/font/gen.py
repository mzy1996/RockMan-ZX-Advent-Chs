from font_bin import FontBin, encode
from PIL import Image, ImageDraw, ImageFont
import os

if __name__ == '__main__':
    W, H = 1024, 1024
    x = y = 0
    review = Image.new('L', (W, H))

    font = ImageFont.truetype('../../libs/Zfull-GB.ttf', size=13)
    msfont = ImageFont.truetype('c:/windows/fonts/msmincho.ttc', size=13)
    im = Image.new('L', (16, 16))
    draw = ImageDraw.ImageDraw(im)
    draw.fontmode = '1'
    texts = open('chars.txt', encoding='utf-8').read()
    fb = FontBin(open('backup/font_jp.bin', 'rb'))
    fb.clear()
    for t in texts:
        name = f'{t}.png'
        if ord(t) > 0x80 and os.path.exists(name):
            im = Image.open(name)
            draw = ImageDraw.ImageDraw(im)
            print(name)
        else:
            draw.rectangle((0, 0, 16, 16), fill=0)
            draw.text((0, 0), t, font=font, fill=255)
            if len(set(im.tobytes())) == 1:
                draw.text((0, 0), t, font=msfont, fill=255)

        review.paste(im, (x, y))
        x += 16
        if x > W:
            x = 0
            y += 16
        fb.append(encode(im))
    fb.save(open('font_cn.bin', 'wb'))
    review.save('1.png')

    # buf = open('font_jp.bin', 'rb').read(0x20)
    # open('font_jp.bin', 'wb').write(buf)
