from PIL import Image
import os
from struct import Struct
from io import BytesIO

Header = Struct('HH3I')


class FontBin(list):
    def __init__(self, io=None):
        if io:
            self.load(io)

    def load(self, io):
        self.size, v10, bin_size, num, buf_size = Header.unpack(io.read(Header.size))
        assert bin_size * num == buf_size
        assert v10 == 0x10

        self.name = io.read(0x10)
        for i in range(num):
            self.append(io.read(bin_size))

    def save(self, io):
        io.write(Header.pack(self.size, 0x10, len(self[0]), len(self), len(self[0]) * len(self)))
        io.write(self.name)
        for b in self:
            io.write(b)


def decode(buf):
    out = BytesIO()
    for b in buf:
        for i in range(8):
            out.write(b'\xff' if (b & 1) == 1 else b'\x00')
            b >>= 1

    im = Image.new('L', (16, 16))
    im.frombytes(out.getvalue())

    return im


def encode(im):
    assert im.size == (16, 16)
    assert im.mode == 'L'

    buf = im.tobytes()
    out = BytesIO()
    io = BytesIO(buf)
    for i in range(len(buf) // 8):
        v = 0
        for i in range(8):
            if int.from_bytes(io.read(1), 'little') > 0:
                v |= 1 << i
        out.write(v.to_bytes(1, 'little'))

    assert out.tell() == 0x20
    return out.getvalue()


if __name__ == '__main__':
    fb = FontBin(open('backup/font_jp.bin', 'rb'))
    W = H = 1024
    x = y = 0
    im = Image.new('L', (W, H))
    for b in fb:
        im.paste(decode(b), (x, y))
        x += 16
        if x > W:
            x = 0
            y += 16
    im.save('jp.png')

    for i, b in enumerate(fb[-7:]):
        decode(b).save(f'{i}.png')
