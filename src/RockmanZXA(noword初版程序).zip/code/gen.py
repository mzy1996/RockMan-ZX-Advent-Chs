import os
from struct import pack
import sys
sys.path.append('../../libs')
from bin_patch_kit import *


ROM_NAME = 'arm9.bin'
CODE_NAME = 'build/main.o'
EMPTY_OFFSET = 0x0011ba90
CODE_OFFSET = EMPTY_OFFSET + 0x80
JOBS = [
    {'arch': 'thumb', 'type': 'hook', 'address': 0x800E8, 'func': 'Hooker020800E8'},
    {'arch': 'thumb', 'type': 'patch', 'address': 0x80486, 'asm': 'cmp r2, #0xe0; blo #0x2080492;'},
    {'arch': 'thumb', 'type': 'patch', 'address': 0x8048E, 'asm': 'mov r0, r0; mov r0, r0;'},
    {'arch': 'arm', 'type': 'patch', 'address': 0x000898, 'asm': 'mov r0, r0'},  # MIi_UncompressBackward
]


buf = open(f'backup/{ROM_NAME}', 'rb').read()[: -0xc]
open(ROM_NAME, 'wb').write(buf)
os.system(f'blz -d {ROM_NAME}')

size = os.path.getsize(ROM_NAME)

patch_rom(ROM_NAME,
          NDS_BASE,
          CODE_NAME,
          CODE_OFFSET,
          JOBS
          )

with open(ROM_NAME, 'rb+') as fp:
    rom_buf = fp.read(size)
    fp.seek(EMPTY_OFFSET, os.SEEK_SET)
    fp.write(b'font_cn.bin\x00')

    fp.seek(EMPTY_OFFSET, os.SEEK_SET)
    buf = fp.read()

open(ROM_NAME, 'wb').write(rom_buf)
with open('font_jp.bin', 'rb+') as fp:
    fp.seek(0x4504, os.SEEK_SET)
    fp.write(buf)
