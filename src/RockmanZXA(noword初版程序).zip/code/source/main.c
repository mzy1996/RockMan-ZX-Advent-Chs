#include <nds.h>
#include "registers.h"

// #define ENABLE_LOGGING
#include "log.h"

typedef int BOOL;
typedef signed long s32;
typedef char FSFile[0x30];
typedef enum
{
    FS_SEEK_SET, /* seek from begin*/
    FS_SEEK_CUR, /* seek from current*/
    FS_SEEK_END  /* seek from end*/
} FSSeekFileMode;

typedef void (*FUNC_FS_InitFile)(FSFile *p_file);
typedef BOOL (*FUNC_FS_OpenFile)(FSFile *p_file, const char *path);
typedef BOOL (*FUNC_FS_SeekFile)(FSFile *p_file, s32 offset, FSSeekFileMode origin);
typedef s32 (*FUNC_FS_ReadFile)(FSFile *p_file, void *dst, s32 len);

const FUNC_FS_InitFile FS_InitFile = (FUNC_FS_InitFile)0x020ACF34;
const FUNC_FS_OpenFile FS_OpenFile = (FUNC_FS_OpenFile)0x020ACBE4;
const FUNC_FS_SeekFile FS_SeekFile = (FUNC_FS_SeekFile)0x020ACA14;
const FUNC_FS_ReadFile FS_ReadFile = (FUNC_FS_ReadFile)0x020ACA80;

struct VARS
{
    char font_name[0x10];
    uint32_t tile_count;
    uint32_t opened;
    FSFile file;
};

#define ROM_FONT_OFFSET 0x021175ac
#define FONT_TILE_NUM 0x200
#define FONT_TILE_SIZE 0x20
#define FONT_HEADER_SIZE 0x20

#define VARS_OFFSET 0x0211ba90

__attribute__((target("thumb"))) void Hooker020800E8(struct Registers *regs)
{
    LOG("Hooker020800E8 start")

    struct VARS *var = (struct VARS *)VARS_OFFSET;

    if (var->opened == 0)
    {
        (*FS_InitFile)(&var->file);
        if ((*FS_OpenFile)(&var->file, var->font_name))
        {
            LOG("file opened");
            var->opened = 1;
        }
    }

    s32 c = regs->r0;
    if (c >= 0xe0)
    {
        char **s = (char **)(regs->sp + 0xc);
        (*s)++;
        c -= 0xe0;
        c++;
        c *= 0xe0;
        c += **s;
    }
    (*FS_SeekFile)(&var->file, FONT_HEADER_SIZE + c * FONT_TILE_SIZE, FS_SEEK_SET);
    if ((*FS_ReadFile)(&var->file, (void *)(ROM_FONT_OFFSET + var->tile_count * FONT_TILE_SIZE), FONT_TILE_SIZE) != FONT_TILE_SIZE)
    {
        LOG("failed to read file");
    }
    regs->r0 = var->tile_count;
    var->tile_count++;
    if (var->tile_count >= FONT_TILE_NUM)
    {
        var->tile_count = 0;
    }

    LOG("Hooker020800E8 end");
}

int main(int argc, char **argv)
{
    return 0;
}